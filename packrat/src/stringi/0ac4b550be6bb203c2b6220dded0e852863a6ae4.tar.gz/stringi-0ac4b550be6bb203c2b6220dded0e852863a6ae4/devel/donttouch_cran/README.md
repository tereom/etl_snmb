The contents of these files have been accepted by the CRAN maintainers.
They are "extremely fragile". :)


No "all rights reserved"

License: file LICENSE only (marked as FOSS by CRAN now)

check ASan & UBSan & valgrind

